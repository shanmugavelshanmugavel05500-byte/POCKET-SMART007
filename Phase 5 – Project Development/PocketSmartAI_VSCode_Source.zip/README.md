# PocketSmart AI

A student-friendly Flask implementation of the PocketSmart AI project described in the supplied project document.

## Modules
1. Home Interior Planner
2. Party Budget Planner
3. Jewelry Recommendation Planner with optional outfit image
4. Login/Register demo
5. Platform search links
6. Gemini AI integration with offline demo fallback

## Important
The supplied document describes Flask in the architecture section but later includes FastAPI screenshots/code. This runnable version uses Flask consistently so it is easier to run in VS Code while preserving the three planners and Gemini workflow.

The current Gemini SDK uses `google-genai`. The `.env` file is not committed to GitHub.

## Run
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python app.py
```

Open http://127.0.0.1:5000

If GEMINI_API_KEY is not configured, the application still runs in Demo Mode so you can test the UI and output. Add a valid key to enable Gemini-generated recommendations.
