import os
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

from gemini_utils import (
    generate_home_recommendations,
    generate_party_recommendations,
    generate_jewelry_recommendations,
)

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "pocketsmart-demo-secret")
UPLOAD_FOLDER = os.path.join("static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
USERS = {}  # Demo only; use a database for a real deployment.


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
def index():
    return render_template("index.html", user=session.get("user"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not username or not password:
            flash("Enter both username and password.")
            return redirect(url_for("register"))
        if username in USERS:
            flash("Username already exists.")
            return redirect(url_for("register"))
        USERS[username] = password
        session["user"] = username
        return redirect(url_for("dashboard"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if USERS.get(username) == password:
            session["user"] = username
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", user=session.get("user"))


@app.route("/home-planner", methods=["GET", "POST"])
def home_planner():
    result = None
    if request.method == "POST":
        try:
            data = {
                "total_budget": float(request.form.get("total_budget", 0)),
                "rooms": request.form.getlist("rooms"),
                "num_lights": int(request.form.get("num_lights", 0)),
                "num_fans": int(request.form.get("num_fans", 0)),
                "num_furniture": int(request.form.get("num_furniture", 0)),
                "num_dining_tables": int(request.form.get("num_dining_tables", 0)),
                "additional_requirements": request.form.get("additional_requirements", ""),
            }
            result = generate_home_recommendations(data)
        except ValueError:
            flash("Please enter valid numbers.")
    return render_template("home_planner.html", result=result)


@app.route("/party-planner", methods=["GET", "POST"])
def party_planner():
    result = None
    if request.method == "POST":
        try:
            data = {
                "total_budget": float(request.form.get("total_budget", 0)),
                "party_type": request.form.get("party_type", ""),
                "num_guests": int(request.form.get("num_guests", 0)),
                "venue_type": request.form.get("venue_type", ""),
                "needs_catering": request.form.get("needs_catering") == "yes",
                "needs_decoration": request.form.get("needs_decoration") == "yes",
                "needs_entertainment": request.form.get("needs_entertainment") == "yes",
                "additional_requirements": request.form.get("additional_requirements", ""),
            }
            result = generate_party_recommendations(data)
        except ValueError:
            flash("Please enter valid numbers.")
    return render_template("party_planner.html", result=result)


@app.route("/jewelry-planner", methods=["GET", "POST"])
def jewelry_planner():
    result = None
    uploaded_image = None

    if request.method == "POST":
        try:
            budget = float(request.form.get("total_budget", 0))
            occasion = request.form.get("occasion", "")
            style = request.form.get("style", "")
            additional_requirements = request.form.get("additional_requirements", "")

            image_path = None
            file = request.files.get("outfit_image")
            if file and file.filename:
                if not allowed_file(file.filename):
                    flash("Only PNG, JPG, JPEG and WEBP images are allowed.")
                    return redirect(url_for("jewelry_planner"))
                filename = secure_filename(file.filename)
                save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                file.save(save_path)
                image_path = save_path
                uploaded_image = url_for("static", filename=f"uploads/{filename}")

            data = {
                "total_budget": budget,
                "occasion": occasion,
                "style": style,
                "additional_requirements": additional_requirements,
            }
            result = generate_jewelry_recommendations(data, image_path)
        except ValueError:
            flash("Please enter a valid budget.")

    return render_template(
        "jewelry_planner.html",
        result=result,
        uploaded_image=uploaded_image,
    )


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
