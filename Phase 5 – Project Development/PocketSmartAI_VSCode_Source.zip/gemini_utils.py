import json
import os
from urllib.parse import quote_plus

try:
    from google import genai
    from PIL import Image
except ImportError:
    genai = None
    Image = None

MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
API_KEY = os.getenv("GEMINI_API_KEY")


def platform_links(search_term, platforms):
    q = quote_plus(search_term)
    base = {
        "Amazon": f"https://www.amazon.in/s?k={q}",
        "Flipkart": f"https://www.flipkart.com/search?q={q}",
        "IKEA": f"https://www.ikea.com/in/en/search/?q={q}",
        "Myntra": f"https://www.myntra.com/{q.replace('+', '-')}",
        "Swiggy": f"https://www.swiggy.com/search?query={q}",
        "Zomato": f"https://www.zomato.com/search?query={q}",
        "Booking": f"https://www.booking.com/searchresults.html?ss={q}",
        "OYO": f"https://www.oyorooms.com/search?location={q}",
    }
    return {p: base[p] for p in platforms if p in base}


def extract_json(text):
    if not text:
        return None
    text = text.strip()
    if text.startswith("```"):
        text = text.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1:
            try:
                return json.loads(text[start:end + 1])
            except json.JSONDecodeError:
                return None
    return None


def call_gemini(prompt, image_path=None):
    if not API_KEY or genai is None:
        return None

    client = genai.Client(api_key=API_KEY)

    contents = [prompt]
    if image_path and Image:
        image = Image.open(image_path)
        contents.append(image)

    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=contents,
    )
    return extract_json(response.text)


def generate_home_recommendations(data):
    prompt = f"""
You are PocketSmart AI, a budget recommendation assistant for users in India.
Create practical home interior recommendations using INR prices.
Budget: ₹{data['total_budget']:.0f}
Rooms: {", ".join(data['rooms']) or "Not specified"}
Lights: {data['num_lights']}
Fans: {data['num_fans']}
Furniture items: {data['num_furniture']}
Dining tables: {data['num_dining_tables']}
Additional requirements: {data['additional_requirements'] or "None"}

Return ONLY valid JSON:
{{
  "title": "Home Interior Budget Plan",
  "budget_breakdown": [
    {{
      "category": "Lighting",
      "allocation": 0,
      "items": [
        {{"name": "", "description": "", "estimated_price": 0, "quantity": 1, "search_terms": ""}}
      ]
    }}
  ],
  "remaining_budget": 0,
  "tips": []
}}
Ensure the estimated total stays within the budget.
"""
    result = call_gemini(prompt)
    if result:
        for category in result.get("budget_breakdown", []):
            for item in category.get("items", []):
                item["shopping_links"] = platform_links(
                    item.get("search_terms") or item.get("name", ""),
                    ["Amazon", "Flipkart", "IKEA"],
                )
        return result

    # Offline demo fallback
    budget = data["total_budget"]
    lighting = min(budget * 0.15, budget)
    furniture = min(budget * 0.45, budget - lighting)
    decor = max(budget - lighting - furniture, 0)
    return {
        "title": "Home Interior Budget Plan (Demo Mode)",
        "budget_breakdown": [
            {"category": "Lighting", "allocation": round(lighting), "items": [
                {"name": "LED ceiling lights", "description": "Energy-efficient lights", "estimated_price": 1200, "quantity": max(data["num_lights"], 1), "search_terms": "LED ceiling light", "shopping_links": platform_links("LED ceiling light", ["Amazon", "Flipkart", "IKEA"])}
            ]},
            {"category": "Furniture", "allocation": round(furniture), "items": [
                {"name": "Budget furniture set", "description": "Simple functional furniture", "estimated_price": 8000, "quantity": max(data["num_furniture"], 1), "search_terms": "budget home furniture", "shopping_links": platform_links("budget home furniture", ["Amazon", "Flipkart", "IKEA"])}
            ]},
            {"category": "Decor", "allocation": round(decor), "items": [
                {"name": "Wall decor", "description": "Affordable decorative items", "estimated_price": 1500, "quantity": 1, "search_terms": "home wall decor", "shopping_links": platform_links("home wall decor", ["Amazon", "Flipkart", "IKEA"])}
            ]},
        ],
        "remaining_budget": round(max(budget - lighting - furniture - decor, 0)),
        "tips": ["Add GEMINI_API_KEY in .env to enable live AI-generated recommendations."]
    }


def generate_party_recommendations(data):
    prompt = f"""
You are PocketSmart AI for party planning in India.
Budget: ₹{data['total_budget']:.0f}
Event: {data['party_type']}
Guests: {data['num_guests']}
Venue: {data['venue_type']}
Catering: {"Yes" if data['needs_catering'] else "No"}
Decoration: {"Yes" if data['needs_decoration'] else "No"}
Entertainment: {"Yes" if data['needs_entertainment'] else "No"}
Additional requirements: {data['additional_requirements'] or "None"}

Return ONLY valid JSON:
{{
  "title": "Party Budget Plan",
  "budget_breakdown": [
    {{
      "category": "Catering",
      "allocation": 0,
      "items": [{{"name": "", "description": "", "estimated_price": 0, "quantity": 1, "search_terms": ""}}]
    }}
  ],
  "remaining_budget": 0,
  "tips": []
}}
Keep the total within the budget and use INR.
"""
    result = call_gemini(prompt)
    if result:
        for category in result.get("budget_breakdown", []):
            for item in category.get("items", []):
                item["shopping_links"] = platform_links(
                    item.get("search_terms") or item.get("name", ""),
                    ["Swiggy", "Zomato", "Amazon", "Flipkart", "OYO"],
                )
        return result

    budget = data["total_budget"]
    catering = round(budget * 0.50 if data["needs_catering"] else 0)
    decoration = round(budget * 0.20 if data["needs_decoration"] else 0)
    entertainment = round(budget * 0.15 if data["needs_entertainment"] else 0)
    venue = round(budget * 0.10)
    used = catering + decoration + entertainment + venue
    return {
        "title": "Party Budget Plan (Demo Mode)",
        "budget_breakdown": [
            {"category": "Catering", "allocation": catering, "items": [
                {"name": "Party catering", "description": f"Food plan for {data['num_guests']} guests", "estimated_price": catering, "quantity": 1, "search_terms": "party catering", "shopping_links": platform_links("party catering", ["Swiggy", "Zomato"])}
            ]},
            {"category": "Decoration", "allocation": decoration, "items": [
                {"name": "Event decoration", "description": "Basic theme decoration", "estimated_price": decoration, "quantity": 1, "search_terms": "party decoration", "shopping_links": platform_links("party decoration", ["Amazon", "Flipkart"])}
            ]},
            {"category": "Entertainment", "allocation": entertainment, "items": [
                {"name": "Entertainment setup", "description": "Basic entertainment", "estimated_price": entertainment, "quantity": 1, "search_terms": "party entertainment", "shopping_links": platform_links("party entertainment", ["Amazon"])}
            ]},
            {"category": "Venue", "allocation": venue, "items": [
                {"name": "Venue search", "description": "Venue options for the event", "estimated_price": venue, "quantity": 1, "search_terms": data["venue_type"] or "party venue", "shopping_links": platform_links(data["venue_type"] or "party venue", ["OYO", "Booking"])}
            ]},
        ],
        "remaining_budget": max(budget - used, 0),
        "tips": ["Enable Gemini in .env for AI-generated event-specific planning."]
    }


def generate_jewelry_recommendations(data, image_path=None):
    prompt = f"""
You are PocketSmart AI, a jewelry recommendation assistant for India.
Budget: ₹{data['total_budget']:.0f}
Occasion: {data['occasion']}
Style: {data['style']}
Additional requirements: {data['additional_requirements'] or "None"}
If an outfit image is provided, consider its visible colors and style.

Return ONLY valid JSON:
{{
  "title": "Jewelry Recommendation Plan",
  "outfit_analysis": {{"colors": "", "style": "", "formality": ""}},
  "jewelry_recommendations": [
    {{"item_type": "", "description": "", "style": "", "estimated_price": 0, "search_terms": ""}}
  ],
  "remaining_budget": 0,
  "styling_tips": []
}}
Keep recommendations within budget.
"""
    result = call_gemini(prompt, image_path)
    if result:
        for item in result.get("jewelry_recommendations", []):
            item["shopping_links"] = platform_links(
                item.get("search_terms") or item.get("item_type", ""),
                ["Amazon", "Flipkart", "Myntra"],
            )
        return result

    return {
        "title": "Jewelry Recommendation Plan (Demo Mode)",
        "outfit_analysis": {"colors": "Not analyzed", "style": data["style"], "formality": data["occasion"]},
        "jewelry_recommendations": [
            {"item_type": "Earrings", "description": "Elegant matching earrings", "style": data["style"], "estimated_price": min(1500, data["total_budget"]), "search_terms": "elegant earrings", "shopping_links": platform_links("elegant earrings", ["Amazon", "Flipkart", "Myntra"])},
            {"item_type": "Necklace", "description": "Simple occasion necklace", "style": data["style"], "estimated_price": min(2500, max(data["total_budget"] - 1500, 0)), "search_terms": "occasion necklace", "shopping_links": platform_links("occasion necklace", ["Amazon", "Flipkart", "Myntra"])},
        ],
        "remaining_budget": max(data["total_budget"] - min(data["total_budget"], 4000), 0),
        "styling_tips": ["Upload an outfit image and add GEMINI_API_KEY for multimodal AI analysis."]
    }
